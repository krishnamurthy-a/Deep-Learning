from setuptools import setup

VERSION='0.1'
setup(name='custom_functions',
      version=VERSION,
      description='Custom functions for model',
      author='Green Services and Solutions',
      author_email='carlos.patino@greencss.com',
      packages=[
            'custom_functions'
      ],
      zip_safe=False)